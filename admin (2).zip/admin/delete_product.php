<?php
// delete_product.php
include 'connections.php';  // Database connection

// Get the product ID from the URL
$product_ID = $_GET['id'];

// Check if product ID exists
if (!isset($product_ID)) {
    echo "<script>";
    echo "alert('เกิดข้อผิดพลาด: ไม่พบเลขที่สินค้า!');";
    echo "window.location = 'product.php';";  // Redirect to the product listing page
    echo "</script>";
    exit();
}

// Proceed to delete the product from the database
$sql = "DELETE FROM tbl_product WHERE product_ID='$product_ID'";
$result = mysqli_query($con, $sql);

if ($result) {
    echo "<script>";
    echo "alert('ลบสินค้าสำเร็จ!');";
    echo "window.location = 'product.php';";  // Redirect to the product listing page
    echo "</script>";
} else {
    // Display the SQL error if deletion fails
    echo "<script>";
    echo "alert('เกิดข้อผิดพลาด: " . mysqli_error($con) . "');";
    echo "window.location = 'product.php';";
    echo "</script>";
}

// Close the database connection
mysqli_close($con);
?>
