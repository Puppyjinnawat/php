<?php
$con= mysqli_connect("localhost","root","12345678","business");

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error); // ใช้ connect_error สำหรับการตรวจสอบข้อผิดพลาดในการเชื่อมต่อ
}
mysqli_query($con, "SET NAMES 'utf8' ");

error_reporting( error_reporting() & ~E_NOTICE );

date_default_timezone_set('Asia/Bangkok');
?>
