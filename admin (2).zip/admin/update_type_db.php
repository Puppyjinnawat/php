<?php
// edit_product_db.php
include 'connections.php';

// รับค่าจากฟอร์ม
$type_id = $_POST['type_id'];
$type_name = $_POST['type_name'];

// ตรวจสอบว่า type_name มีอยู่แล้วหรือไม่
$sql_check = "SELECT * FROM tbl_type WHERE type_name = '$type_name' AND type_id != '$type_id'";
$result_check = mysqli_query($con, $sql_check);

if (mysqli_num_rows($result_check) > 0) {
    // ถ้าพบ type_name ซ้ำ
    echo "<script>";
    echo "alert('ชื่อประเภทสินค้านี้มีอยู่แล้ว กรุณาใช้ชื่อใหม่');";
    echo "window.history.back();";  // ย้อนกลับไปยังหน้าฟอร์มแก้ไข
    echo "</script>";
} else {
    // ถ้าไม่พบข้อมูลซ้ำ ให้ดำเนินการอัปเดตข้อมูล
    $sql = "UPDATE tbl_type SET
            type_name='$type_name'
            WHERE type_id='$type_id'";

    $result = mysqli_query($con, $sql);

    // ตรวจสอบผลการทำงาน
    if ($result) {
        echo "<script>";
        echo "alert('บันทึกข้อมูลสำเร็จ');";
        echo "window.location = 'typeproduct.php';";  // กลับไปยังหน้ารายการประเภทสินค้า
        echo "</script>";
    } else {
        // แสดงข้อความแจ้งข้อผิดพลาดใน SQL
        echo "<script>";
        echo "alert('เกิดข้อผิดพลาด: " . mysqli_error($con) . "');";
        echo "window.history.back();";
        echo "</script>";
    }
}

// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
