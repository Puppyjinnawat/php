<?php
include 'connections.php';
$id=$_GET['id'];

$sql="UPDATE tbl_order set status=0 where order_id='$id'";
$result = mysqli_query($con, $sql);
if ($result) {
    
    echo "<script>window.location = 'report_order.php';</script>";
    
} else {
    echo "<script>";
    echo "alert('ไม่สามารถลบข้อมูลได้');";
 
    echo "</script>";
}
?>
?>