<?php
// delete_product.php
include 'connections.php';  // Database connection

// Get the product ID from the URL
$type_ID = $_GET['id'];

// Check if product ID exists
if (!isset($type_ID )) {
    echo "<script>";
    echo "alert('เกิดข้อผิดพลาด: ไม่พบเลขที่ประเภทสินค้า!');";
    echo "window.location = 'product.php';";  // Redirect to the product listing page
    echo "</script>";
    exit();
}

// Proceed to delete the product from the database
$sql = "DELETE FROM tbl_type WHERE type_id='$type_ID'";
$result = mysqli_query($con, $sql);

if ($result) {
    echo "<script>";
    echo "alert('ลบสำเร็จ!');";
    echo "window.location = 'typeproduct.php';";  // Redirect to the product listing page
    echo "</script>";
} else {
    // Display the SQL error if deletion fails
    echo "<script>";
    echo "alert('เกิดข้อผิดพลาด: " . mysqli_error($con) . "');";
    echo "window.location = 'typeproduct';";
    echo "</script>";
}

// Close the database connection
mysqli_close($con);
?>
