<?php
include 'connections.php';

// Fetching data from POST request
$product_id = $_POST['product_id'];
$brand = $_POST['brand'];
$type_id = $_POST['type_id'];
$product_name = $_POST['product_name'];
$product_price = $_POST['product_price'];
$product_qty = $_POST['product_qty'];
$product_contry = $_POST['product_contry']; // Fixed variable typo

// ตรวจสอบราคาและปริมาณ
if ($product_price <= 0 || $product_qty <= 0) {
    echo "<script>";
    echo "alert('ราคาและปริมาณสินค้าต้องมากกว่า 0');";
    echo "window.history.back();";  // กลับไปที่ฟอร์มก่อนหน้า
    echo "</script>";
    exit();
}

// ตรวจสอบว่ามี product_id หรือ product_name ซ้ำในฐานข้อมูลหรือไม่
$sql_check = "SELECT * FROM tbl_product WHERE product_id='$product_id' OR product_name='$product_name'";
$result_check = mysqli_query($con, $sql_check);

if (mysqli_num_rows($result_check) > 0) {
    echo "<script>";
    echo "alert('มีข้อมูลที่ซ้ำกันอยู่แล้ว กรุณากรอกใหม่');";
    echo "window.history.back();";  // กลับไปที่ฟอร์มก่อนหน้า
    echo "</script>";
    exit();
}

// SQL query to insert the product data
$sql = "INSERT INTO tbl_product (product_ID, brand, type_ID, product_name, product_price, product_qty, product_contry) 
        VALUES ('$product_id', '$brand', '$type_id', '$product_name', '$product_price', '$product_qty', '$product_contry')";

// Executing the query and checking the result
$result = mysqli_query($con, $sql);

if ($result) {
    echo "<script>";
    echo "alert('บันทึกสำเร็จ');";
    echo "window.location = 'product.php';";
    echo "</script>";
} else {
    echo "<script>";
    echo "alert('บันทึกไม่สำเร็จ: " . mysqli_error($con) . "');"; // แสดงข้อความข้อผิดพลาด
    echo "window.location = 'product.php';";
    echo "</script>";
}

// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
