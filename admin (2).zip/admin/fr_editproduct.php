<?php
// 1. Connect to the database:
include('connections.php');  // File to connect to the database
$product_ID = $_GET["id"];

// 2. Query product information:
$sql_product = "SELECT * FROM tbl_product WHERE product_ID='$product_ID'";
$result_product = mysqli_query($con, $sql_product);
$row_product = mysqli_fetch_array($result_product);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - SB Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <?php include 'menu.php'; ?>
    <div class="container">
        <div id="layoutSidenav_content">
            <main>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="alert alert-primary h4 text-center mb-4 mt-4" role="alert">
                            แก้ไขสินค้า
                        </div>
                        <form name="form1" method="post" action="update_product_db.php" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="product_id" class="form-label">เลขที่สินค้า</label>
                                <input type="text" name="product_id" class="form-control" readonly value="<?= $row_product['product_ID'] ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label for="brand" class="form-label">แบรนด์</label>
                                <input type="text" name="brand" class="form-control" value="<?= $row_product['brand'] ?>">
                            </div>

                            <div class="mb-3">
                                <label for="type_id" class="form-label">ประเภทสินค้า</label>
                                <select class="form-select" name="type_id">
                                    <?php
                                    // 3. Query all types:
                                    $sql_type = "SELECT * FROM tbl_type ORDER BY type_name";
                                    $result_type = mysqli_query($con, $sql_type);
                                    while ($row_type = mysqli_fetch_array($result_type)) {
                                        $selected = ($row_type['type_id'] == $row_product['type_id']) ? "selected" : "";
                                        echo "<option value='" . $row_type['type_id'] . "' $selected>" . $row_type['type_name'] . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="product_name" class="form-label">ชื่อสินค้า</label>
                                <input type="text" name="product_name" class="form-control" value="<?= $row_product['product_name'] ?>">
                            </div>

                            <div class="mb-3">
                                <label for="product_price" class="form-label">ราคา</label>
                                <input type="number" name="product_price" class="form-control" value="<?= $row_product['product_price'] ?>">
                            </div>

                            <div class="mb-3">
                                <label for="product_qty" class="form-label">ปริมาณ</label>
                                <input type="number" name="product_qty" class="form-control" value="<?= $row_product['product_qty'] ?>">
                            </div>

                            <div class="mb-3">
                                <label for="product_contry" class="form-label">ประเทศที่ผลิต</label>
                                <input type="text" name="product_contry" class="form-control" value="<?= $row_product['product_contry'] ?>">
                            </div>

                            <button type="submit" class="btn btn-success">Submit</button>
                            <input class="btn btn-danger" type="reset" value="Cancel">
                        </form>
                    </div>
                </div>
            </main>
        </div>  
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="js/scripts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
<script src="assets/demo/chart-area-demo.js"></script>
<script src="assets/demo/chart-bar-demo.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
<script src="js/datatables-simple-demo.js"></script>

</html>

<?php
// Close the database connection after fetching data
mysqli_close($con);
