<?php
// edit_product_db.php
include 'connections.php';

// Get the form inputs
$product_ID = $_POST['product_id'];
$brand = $_POST['brand'];
$type_id = $_POST['type_id'];
$product_name = $_POST['product_name'];
$product_price = $_POST['product_price'];
$product_qty = $_POST['product_qty'];
$product_contry = $_POST['product_contry'];

// Backend validation: Ensure price and quantity are greater than 0
if ($product_price <= 0 || $product_qty <= 0) {
    echo "<script>";
    echo "alert('ราคาและปริมาณต้องมากกว่า 0');";
    echo "window.history.back();";  // Go back to the previous form
    echo "</script>";
    exit();
}

// Proceed with the database update if validation passes
$sql = "UPDATE tbl_product SET
        brand='$brand',
        type_ID='$type_id',
        product_name='$product_name',
        product_price='$product_price',
        product_qty='$product_qty',
        product_contry='$product_contry'
        WHERE product_ID='$product_ID'";

$result = mysqli_query($con, $sql);

// Check for SQL errors
if ($result) {
    echo "<script>";
    echo "alert('บันทึกข้อมูลสำเร็จ');";
    echo "window.location = 'product.php';";  // Redirect after success
    echo "</script>";
} else {
    // Display detailed error message
    echo "<script>";
    echo "alert('เกิดข้อผิดพลาด: " . mysqli_error($con) . "');";
    echo "window.history.back();";
    echo "</script>";
}

mysqli_close($con);
?>
