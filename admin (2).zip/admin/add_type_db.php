<?php
include 'connections.php';

// Fetching data from POST request
$type_id = $_POST['type_id'];
$type_name = $_POST['type_name'];
// Fixed variable typo
$sql_check = "SELECT * FROM tbl_type WHERE type_name = '$type_name' AND type_id != '$type_id'";
$result_check = mysqli_query($con, $sql_check);
if (mysqli_num_rows($result_check) > 0) {
    // ถ้าพบ type_name ซ้ำ
    echo "<script>";
    echo "alert('ชื่อประเภทสินค้านี้มีอยู่แล้ว กรุณาใช้ชื่อใหม่');";
    echo "window.history.back();";  // ย้อนกลับไปยังหน้าฟอร์มแก้ไข
    echo "</script>";
}
// SQL query to insert the product data
$sql = "INSERT INTO tbl_type ( type_id,type_name) 
        VALUES ('$type_id','$type_name')";

// Executing the query and checking the result
$result = mysqli_query($con, $sql);

if ($result) {
    echo "<script>";
    echo "alert('บันทึกสำเร็จ');";
    echo "window.location = 'typeproduct.php';";
    echo "</script>";
} else {
    echo "<script>";
    echo "alert('บันทึกไม่สำเร็จ');";
    echo "window.location = 'typeproduct.php';";
    echo "</script>";
}
?>
